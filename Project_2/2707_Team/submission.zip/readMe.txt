Read me

The file is placed in the same level as Test and Train Data.

-train.txt
-test.txt
-NER.py

Run NER.py with the python 3 interpreter